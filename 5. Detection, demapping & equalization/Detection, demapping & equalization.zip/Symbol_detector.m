function detected_symbols = Symbol_detector(zQ, modulation_type, A)
% INPUTS:
% zQ: vector containing num_symbols samples of z_Q[k];
% modulation_type: 'bpsk' or 'qpsk'
% A: separation of adjacent symbols at the output
% OUTPUT: 
% detected_symbols: vector of length num_symbols containing the MAP decisions ahat[k] on the transmitted symbols a[k].

%Prueba
%%A = 1;
%%zQ = [-0.3+0.1j, -0.9-0.4j, 0.7-0.1j, -0.8+0.6j, 0.7+0.2j];
%%detected_symbols = Symbol_detector(zQ, 'qpsk', A);
%%disp(detected_symbols);

zQ_real = real(zQ);
zQ_imag = imag(zQ);
num_symbols = length(zQ);
detected_symbols = zeros(1, num_symbols);

if strcmpi(modulation_type, 'bpsk') 

    for n = 1:num_symbols
        if zQ_real(n) >= 0
            detected_symbols(n) = A/2;  %R1
        else
            detected_symbols(n) = -A/2; %R2
        end
    end

elseif strcmpi(modulation_type, 'qpsk')

    for n = 1:num_symbols
        if zQ_real(n) >= 0 && zQ_imag(n) >= 0
            detected_symbols(n) = (A/2) + 1j*(A/2);   %R1      
        elseif zQ_real(n) < 0 && zQ_imag(n) >= 0
            detected_symbols(n) = -(A/2) + 1j*(A/2);   %R2     
        elseif zQ_real(n) >= 0 && zQ_imag(n) < 0
            detected_symbols(n) = (A/2) - 1j*(A/2);     %R3  
        elseif zQ_real(n) < 0 && zQ_imag(n) < 0
            detected_symbols(n) = -(A/2) - 1j*(A/2);    %R4    
        end
    end

else
    error('This function only supports BPSK and QPSK')

end