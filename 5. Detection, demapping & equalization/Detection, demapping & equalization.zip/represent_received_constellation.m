function represent_received_constellation(num_symbols,symbols)

% num_symbols: number of transmitted symbols
% output_matched_filter_decimated: output of the matched after decimation (1 sample per symbol)


constellation = symbols(5:(num_symbols-5));   % decimation at the output of the matched_filter
                                                                      % We do not plot the first 5 and the last 5 symbols to avoid see transient effects

figure;
plot(constellation,'.')

