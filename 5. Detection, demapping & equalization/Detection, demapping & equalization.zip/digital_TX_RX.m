clear all
close all

fs=44100;  % sampling frequency
Ts=1/fs;  % sampling period
Nss=4;   % oversampling (samples/symbol)
Tsym=Ts*Nss;  % symbol period
modulation_type = 'qpsk';   % bpsk or  qpsk
prob = 0.5;  % probability of bit = 1
A = 1;  % separation of adjacent symbols
num_symbols = 10000;  % transmission length (in symbols)

%%%%%%%%%%%%%%%% CHANNEL %%%%%%%%%%%%%%%%%%%%%%%

SNR = 100;  % SNR at the (decimated) matched filter output
amp_echo = -0.4; % channel echo amplitude 
delay_echo = 1; % channel echo delay (in symbol periods)
channel = channel_impulse_response(delay_echo,amp_echo,Nss); % channel imp. response

%%%%%%%%%%%%%%%% CARRIER  %%%%%%%%%%%%%%%%%%%%%%%

A0 = 1;   % carrier sinuoid amplitude
f0 = fs/4;   % carrier sinusoid analog frequency (cycles/second=Hz)
phi_0 = 0; % initial phase of the transmitter carrier

%%%%%%%%%%%%%%%% PULSE-SHAPING %%%%%%%%%%%%%%%%%%%%

Pulse.type='srrc___';                      
if Pulse.type=='rectNRZ'
    g_pulse = ones(1,Nss)/sqrt(Tsym);  % NRZ rectangular pulse of unit energy
elseif Pulse.type=='rectRZ_'
    g_pulse = ones(1,Nss/2)/sqrt(Tsym/2);  % RZ rect. pulse of unit energy (50% duty-cycle)
elseif Pulse.type=='srrc___'  
    Pulse.D = 6;   % pulse half-length, in symbol periods
    Pulse.alpha = 0.5;   % pulse roll-off (excess bandwidth)
    g_pulse = srrc(Pulse.D, Pulse.alpha, Nss, Tsym);    % SRRC pulse of unit energy
end
Lpulse = length(g_pulse);  % pulse length in samples


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%% TX AND RX PROCESSING CHAINS %%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% --------------------  Generation of random bits and symbols ------------------------------------

num_bits = num_symbols*num_bits_symbol(modulation_type);   % number of bits per block
bits = rand(1,num_bits)<prob;  % random independent bits with prob(bit=1) = prob
symbols = mapping(bits,modulation_type,A);      % mapping from bits to symbols

% --------------------- Complex baseband TX signal -----------------------------------------------

N = num_symbols*Nss+max(0,Lpulse-Nss);   % block length (in samples)
baseband_tx = zeros(1,N);
for k=1:num_symbols,
    baseband_tx((k-1)*Nss+(1:Lpulse)) = baseband_tx((k-1)*Nss+(1:Lpulse))...
                                                            + symbols(k)*g_pulse;
end

% --------------------- Bandpass TX signal ----------------------------------------------------------
   
n = [0:N-1];   % discrete time index within a block
signal_tx = real(baseband_tx.*A0.*exp(j*(2*pi*f0*n*Ts+phi_0)));   % discrete I/Q signal

% --------------------- Channel -----------------------------------------------------------------------

signal_rx = conv(signal_tx,channel);   % channel convolution
RX_signal_power = mean(signal_rx.^2);   % RX desired signal power
Pn = RX_signal_power/(10^(SNR/10))*Nss/2;   % RX noise power
signal_rx = signal_rx+sqrt(Pn)*randn(size(signal_rx));   % addition of AWGN

% --------------------- I/Q demodulation ------------------------------------------------------------

phi_r = phi_0 + 0;  % delay of first ray is assumed to be zero 
v = signal_rx*(2/A0).*exp(-j*(2*pi*f0*(0:(length(signal_rx)-1))*Ts+phi_r));  
baseband_rx = v;  % IQ-demod low-pass filter is omitted: filtering done by matched filter

% --------------------- Matched-filtering -------------------------------------------------------------

output_matched_filter = conv(baseband_rx,fliplr(g_pulse))*Ts;

% ----------------- Sample selection and decimation (1 sample/symbol) -------------------------

n0 = Lpulse;   % Sample corresponding to the maximum of the first received symbol
output_matched_filter_decimated = output_matched_filter(n0+(0:(num_symbols-1))*Nss);  

% Constellation (matched filter ouput)
represent_received_constellation(num_symbols,output_matched_filter_decimated);
set(gcf, 'Position', [250, 250, 500, 500]);
title('Constellation (matched-filter output)' ), grid on, xlim([-1.2 1.2]); ylim([-1.2 1.2]);

% ------------------------------------------------------------------------------------------------------
%                              TASK 1: symbol detection (matched filter output) 
% ------------------------------------------------------------------------------------------------------

detected_symbols = Symbol_detector(output_matched_filter_decimated,modulation_type,A);

% Symbol error rate analysis (matched filter output)
Pe_estimated  = sum(symbols~=detected_symbols)/length(symbols); % estimated Pe
str = sprintf('Estimated Pe = %0.1e',Pe_estimated);
annotation('textbox', [0.15, 0.87, 0.24, 0.04], 'String', str, 'BackgroundColor', 'white');


% ------------------------------------------------------------------------------------------------------
%                                                  TASK 2: De-mapping 
% ------------------------------------------------------------------------------------------------------

% ***************** UNCOMMENT NEXT LINES **********************************

 detected_bits = Demapper(detected_symbols,modulation_type,A); 

% Bit error rate estimation
Pb_estimated  = sum(bits~=detected_bits)/length(bits);
disp(['Estimated Bit Error Rate (MF output) = ' num2str(Pb_estimated)])

% *************************************************************************


% ------------------------------------------------------------------------------------------------------
%              TASK 3: Equalization for a two-rays channel
% ------------------------------------------------------------------------------------------------------


% ***************** UNCOMMENT NEXT LINES **********************************

 hq = [1, 0.4, 0.16]; % 3-coefs equalizer
 output_equalizer = conv(output_matched_filter_decimated,hq);
 output_equalizer = output_equalizer(1:end-length(hq)+1);

 represent_received_constellation(num_symbols,output_equalizer);
 set(gcf, 'Position', [800, 250, 500, 500]);
 title('Constellation (equalizer output)' ), grid on, xlim([-1.2 1.2]); ylim([-1.2 1.2]);
 detected_symbols_equalizer = Symbol_detector(output_equalizer,modulation_type,A);
 Pe_estimated_equalizer  = sum(symbols~=detected_symbols_equalizer)/length(symbols); 

 str=sprintf('Estimated Pe = %0.1e',Pe_estimated_equalizer);
 annotation('textbox', [0.15, 0.87, 0.24, 0.04], 'String', str, 'BackgroundColor', 'white');
 
 detected_bits = Demapper(detected_symbols_equalizer,modulation_type,A);
 Pb_estimated  = sum(bits~=detected_bits)/length(bits); % estimated Pb
 disp(['Estimated Bit Error Rate (Equalizer output) = ' num2str(Pb_estimated)])

% *************************************************************************