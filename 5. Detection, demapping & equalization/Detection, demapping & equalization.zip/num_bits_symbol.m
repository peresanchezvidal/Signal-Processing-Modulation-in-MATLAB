function b = num_bits_symbol(modulation_type)

% modulation_type: bpsk, qpsk, uni-2pam, uni-4pam, bip-4pam, 16-qam
% b: numbre of bits per symbol

switch modulation_type
    case 'bpsk'
        b=1;
    case 'qpsk'
        b=2;
    case 'uni-2pam'
        b=1;
    case 'uni-4pam'
        b=2;
    case 'bip-4pam'
        b=2;
    case '16-qam'
        b=4;
    otherwise
        b=0;
end