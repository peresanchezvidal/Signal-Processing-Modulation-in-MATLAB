function channel = channel_impulse_response(delay,amp_echo,Nss)

% Function that generates a channel impulse response with 2 echoes. The
% channel impulse response returned by the function has to be sampled at
% Nss samples per symbol period.

% The first echo has always no delay and amplitude equal to 1.

% The second echo has a delay equal to "delay" (in number of symbol periods,
% that may be fractional) and an amplitude "amp_echo".
% If amp_echo=0, then there is no second-ray and the channel is ideal.

% channel: vector containing the impulse response of the channel with Nss
% samples per symbol period.


if amp_echo==0,    % ideal channel
    channel = 1;
else
    channel = 1;
    d1 = round(delay*Nss);    % Delay of the 2nd ray in samples
    channel(1,d1+1) = amp_echo;
end