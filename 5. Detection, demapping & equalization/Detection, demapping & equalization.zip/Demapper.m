function detected_bits = Demapper(detected_symbols, modulation_type, A)
% INPUTS:
% detected_symbols: vector of symbols drawn from a 'bpsk' or 'qpsk' constellation
% modulation_type: 'bpsk' or 'qpsk'
% A: symbols separation of adjacent symbols in the constellation
% OUTPUTS:
% detected_bits: sequence of bits associated to the de-mapper input (detected_symbols)


%%Prueba
%{
A = 1;
detected_symbols = [ 
    A/2 + 1j*A/2,  00
   -A/2 + 1j*A/2,  01
   -A/2 - 1j*A/2,  11
    A/2 - 1j*A/2]; 10

detected_bits = Demapper(detected_symbols, 'qpsk', A);

disp('Símbolos detectados:');
disp(detected_symbols);
disp('Bits detectados (Gray):');
disp(detected_bits);

%}

num_symbols = length(detected_symbols);

if strcmpi(modulation_type, 'bpsk')
    
    detected_bits = zeros(1, num_symbols); % 1 bit por símbolo
    for n = 1:num_symbols
        if detected_symbols(n) == A/2
            detected_bits(n) = 1;
        elseif detected_symbols(n) == -A/2
            detected_bits(n) = 0;
        end
    end

elseif strcmpi(modulation_type, 'qpsk')
    
    detected_bits = zeros(1, 2 * num_symbols); 

    for n = 1:num_symbols
        sym = detected_symbols(n);
        if sym == (A/2 + 1j*A/2)
            detected_bits(2*n - 1) = 0;
            detected_bits(2*n)     = 0;
        elseif sym == (-A/2 + 1j*A/2)
            detected_bits(2*n - 1) = 0;
            detected_bits(2*n)     = 1;
        elseif sym == (A/2 - 1j*A/2)
            detected_bits(2*n - 1) = 1;
            detected_bits(2*n)     = 0;
        elseif sym == (-A/2 - 1j*A/2)
            detected_bits(2*n - 1) = 1;
            detected_bits(2*n)     = 1;
        end
    end

else
    error('This function only supports BPSK and QPSK')
end