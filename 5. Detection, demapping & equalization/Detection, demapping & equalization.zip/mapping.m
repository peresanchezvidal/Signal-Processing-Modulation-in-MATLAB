function symbols = mapping(bits,modulation_type,A)

% bits: sequence of logical bits
% modulation_type: bpsk, qpsk, uni-2pam, uni-4pam, bip-4pam, 16-qam
% A: separation between adjacent symbols

b=num_bits_symbol(modulation_type);
num_symbols = length(bits)/num_bits_symbol(modulation_type);

C = 2.^[b-1:-1:0]*reshape(bits,b,num_symbols);   % grouped bits

switch modulation_type

    case 'bpsk'
        symbols = -A/2*(C==0)+A/2*(C==1);
     
    case 'qpsk'
        symbols = (A/2+j*A/2)*(C==0)+(-A/2+j*A/2)*(C==1)+(A/2-j*A/2)*(C==2)+(-A/2-j*A/2)*(C==3);

    case 'uni-2pam'
        symbols = 0*(C==0)+A*(C==1);
        
    case 'uni-4pam'
        symbols = 0*(C==0)+A*(C==1)+3*A*(C==3)+2*A*(C==2);            

    case 'bip-4pam'
        symbols = -3*A/2*(C==0)-A/2*(C==1)+3*A/2*(C==2)+A/2*(C==3);
    
    case '16-qam'
        symbols = (-3*A/2-j*3*A/2)*(C==0)+(-3*A/2-j*A/2)*(C==1)+(-A/2-j*3*A/2)*(C==2)+(-A/2-j*A/2)*(C==3)+...
            (-3*A/2+j*3*A/2)*(C==4)+(-3*A/2+j*A/2)*(C==5)+(-A/2+j*3*A/2)*(C==6)+(-A/2+j*A/2)*(C==7)+...
            (3*A/2-j*3*A/2)*(C==8)+(3*A/2-j*A/2)*(C==9)+(A/2-j*3*A/2)*(C==10)+(A/2-j*A/2)*(C==11)+...
            (3*A/2+j*3*A/2)*(C==12)+(3*A/2+j*A/2)*(C==13)+(A/2+j*3*A/2)*(C==14)+(A/2+j*A/2)*(C==15);

end