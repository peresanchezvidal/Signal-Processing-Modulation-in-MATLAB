function b = num_bits_symbol(modulation_type)

% modulation_type: bpsk, qpsk, 2-uni, 4-uni, 4-pol, 16-qam
% b: numbre of bits per symbol

switch modulation_type
    case 'bpsk'
        b=1;
    case 'qpsk'
        b=2;
    case '2-uni'
        b=1;
    case '4-uni'
        b=2;
    case '4-pol'
        b=2;
    case '16-qam'
        b=4;
    otherwise
        b=0;
end