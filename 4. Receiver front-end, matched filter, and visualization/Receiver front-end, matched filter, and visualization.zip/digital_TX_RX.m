clear all
close all

fs=44100;       % sampling frequency
Ts=1/fs;        % sampling period
Nss=2000;        % oversampling (samples/symbol)
Tsym=Ts*Nss;    % symbol period
modulation_type = '16-qam';        % bpsk, qpsk, 2-uni, 4-uni, 4-pol, 16-qam
prob = 0.5;     % probability of bit=1
A = 1;          % separation between adjacent symbols
num_symbols = 2000;         % transmission length (in symbols)
SNR = 2000;        % SNR in dB (at the detection stage)


%%%%%%%%%%%%%%%%% CHANNEL WI
% TH 2 RAYS %%%%%%%%%%%%%%%%%%%%%%%%

delay_echo = 0;   % delay: Delay of the 2nd ray in symbol periods (it can be fractional)
                  % Accordingly, the delay in number of samples is d1 = round(delay_echo*Nss)

amp_echo = 0;     % Amplitude of the echo (amp_echo=0 if there is no 2nd ray)

channel = channel_impulse_response(delay_echo,amp_echo,Nss);


%%%%%%%%%%%%%%%%% CHANNEL WITH 1 DELAYED RAY %%%%%%%%%%%%%%%%%%%%%%%%

%d0 = 0;                     % Delay in number of samples of the only ray
%channel=zeros(1,d0+1);
%channel(d0+1)=1; 


%%%%%%%%%%%%%%%% TRANSMITTER CARRIER %%%%%%%%%%%%%%%%%%%%%%%%%%

A0 = 1;         % carrier amplitude
f0 = fs/16;     % carrier analog frequency (cycles/second=Hz)
phi_0 = 0;      % initial phase of the transmitter carrier


%%%%%%%%%%%%%%%% PULSE-SHAPE %%%%%%%%%%%%%%%%%%%%%%%

Pulse.type='srrc___';                      % rectNRZ: rectangular of duration Tsym; rectRZ_: rectangular of duration Tsym/2; srrc___: square-root raised cosine

if Pulse.type=='rectNRZ'
    g_pulse=ones(1,Nss)/sqrt(Tsym);     % NRZ rectangular pulse of unit energy
elseif Pulse.type=='rectRZ_'
    g_pulse=ones(1,Nss/2)/sqrt(Tsym/2);     % RZ rectangular pulse of unit energy (50% duty cycle)
elseif Pulse.type=='srrc___'
    Pulse.D=6;                          % pulse half-length, in symbol periods
    Pulse.alpha=0.9;                    % pulse roll-off (excess bandwidth)
    g_pulse=srrc(Pulse.D, Pulse.alpha, Nss, Tsym);    % SRRC pulse of unit energy
end
Lpulse=length(g_pulse);                 % pulse length in samples


%%%%%%%%%%%%%% LENGTH OF TRANSMITTED SEQUENCE %%%%%%%%%%%%%%%%

num_bits = num_symbols*num_bits_symbol(modulation_type);      % number of bits per block
N = num_symbols*Nss+max(0,Lpulse-Nss);              % block length (in samples)
n=[0:N-1];                              % discrete time index



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%% TX AND RX PROCESSING CHAINS %%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


    % --------------------  Generation of random bits and symbols --------

    bits = rand(1,num_bits)<prob;       % sequence of random independent bits with probability(bit=1) = prob
    symbols = mapping(bits,modulation_type,A);      % mapping from bits to symbols

    
    % ----------------------- complex baseband TX signal --------------------------------------------------------------
    
    baseband_tx = zeros(1,N);
    for k=1:num_symbols,
        baseband_tx((k-1)*Nss+(1:Lpulse)) = baseband_tx((k-1)*Nss+(1:Lpulse))+symbols(k)*g_pulse;
    end
    
    % ----------------------- bandpass TX signal ----------------------------------------------------------------------
       
    signal_tx = real(baseband_tx.*A0.*exp(j*(2*pi*f0*n*Ts+phi_0)));   % discrete bandpass signal
    
    
    % ------------------------ spectrum representation in MATLAB ------------------------------------------------------------
    
    figure;
    [Xabs,faxis]=spectrum(signal_tx,fs,1);   % computes and plots an estimate of the PSD

    
    % --------------------- received signal (channel + noise) ---------------------------

    signal_rx = conv(signal_tx,channel);                        % effect of channel
    RX_signal_power = mean(signal_rx.^2);                       % RX desired signal power
    Pn = (RX_signal_power/(10^(SNR/10)))*Nss/2;                 % RX noise power
    signal_rx = signal_rx+sqrt(Pn)*randn(size(signal_rx));      % addition of AWGN


    % --------------------- I/Q demodulation --------------------------

    delta_phi = 0;
    phi_r = phi_0 + delta_phi;   % phase of the RX local oscillator
    baseband_rx = signal_rx*(2/A0).*exp(-j*(2*pi*f0*(0:(length(signal_rx)-1))*Ts+phi_r));   % discrete baseband RX signal
    
    % low-pass filtering is not applied since the filtering with matched
    % filter is already a low-pass filtering.
    % If we want to apply a low-pass filter before the matched-filter, this
    % low-pass filter has to be designed and the delay introduced by the
    % filter has to be taken into account.



    % -------------------- matched-filtering --------------------------

    output_matched_filter = conv(baseband_rx,fliplr(g_pulse))*Ts; 
    % complex output of the matched−filter with Nss samples per symbol period


    
    %%%%%%%%%%%%% REPRESENTATION OF THE EYE DIAGRAM %%%%%%%%%%%%%%%%%%%%%%%
    delta_n0 = Nss/8;
    n0 = Lpulse+delta_n0;    % This variable indicates the position of the sample corresponding to the center
                    % of the first received symbol taking into account the length of the pulse-shape and
                    % the matched-filter (it corresponds to the position of the maximum of the
                    % auto-correlation of the pulse-shape)
                    % --- Length of auto-correlation: Lpulse+Lpulse-1
                    % --- Position of the maximum: Lpulse
    
    % n0 = Lpulse+d0;

    represent_eye_diagram(n0,Nss,Lpulse,num_symbols,output_matched_filter);


    
   %%%%%%%%%%%%%%%% REPRESENTATION OF THE RECEIVED CONSTELLATION %%%%%%%%%%

   output_matched_filter_decimated = output_matched_filter(n0+(0:(num_symbols-1))*Nss);     % Decimation after the matched-filter to keep just 1 sample per symbol
   represent_received_constellation(num_symbols,output_matched_filter_decimated);
   set(gcf, 'Position', get(0, 'Screensize'));