function represent_received_constellation(num_symbols,output_matched_filter_decimated)

% num_symbols: number of transmitted symbols
% output_matched_filter_decimated: output of the matched after decimation (1 sample per symbol)


constellation = output_matched_filter_decimated(5:(num_symbols-5));   % decimation at the output of the matched_filter
                                                                      % We do not plot the first 5 and the last 5 symbols to avoid see transient effects


subplot(222);
                                                                      
plot(constellation,'o')
title('Received constellation')