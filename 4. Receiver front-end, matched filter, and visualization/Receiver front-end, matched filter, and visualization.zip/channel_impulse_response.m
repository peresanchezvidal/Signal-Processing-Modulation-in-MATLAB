function channel = channel_impulse_response(delay_echo, amp_echo, Nss)

    max_delay_samples = round(delay_echo * Nss);
    channel = 1;
    
    if amp_echo ~= 0
        
        channel(max_delay_samples + 1) = amp_echo;
               
    end
end