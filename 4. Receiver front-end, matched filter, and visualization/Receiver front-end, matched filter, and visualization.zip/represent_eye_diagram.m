function represent_eye_diagram(n0,Nss,Lpulse,num_symbols,output_matched_filter)

% n0: sample of the vector output_matched_filter correspoing to the sample corresponding to the center of the first symbol

% Nss: number of samples per symbol period
% Lpulse: number of samples of the pulse-shape
% num_symbols: number of transmitted symbols
% output_matched_filter: output of the marched filter with over-sampling


subplot(223);
for k = 5:(num_symbols-5),          % We do not plot the first 5 and the last 5 symbols to avoid see transient effects
    plot((-Nss/2:Nss/2)/Nss,real(output_matched_filter(((k-1)*Nss+n0)+(-Nss/2:Nss/2))));   % x-axis: units in time/T
                                                                                           % y-axis it has to plot the Nss real samples corresponding to the k-th symbol
                                                                                           % at the output of the matched filter where the sample in the center
                                                                                           % corresponds to the maximum of the auto-correlation of the pulse-shape
    xlabel('t/T')
    title('Real part of received eye diagram')
    hold on;
end

subplot(224);
for k = 5:(num_symbols-5),         % We do not plot the first 5 and the last 5 symbols to avoid see transient effects
    plot((-Nss/2:Nss/2)/Nss,imag(output_matched_filter(((k-1)*Nss+n0)+(-Nss/2:Nss/2))));   % x-axis: units in time/T
                                                                                           % y-axis: it has to plot the Nss imaginary samples corresponding to the k-th symbol
                                                                                           % at the output of the matched filter where the sample in the center
                                                                                           % corresponds to the maximum of the auto-correlation of the pulse-shape
    xlabel('t/T')
    title('Imaginary part of received eye diagram')
    hold on;
   
end