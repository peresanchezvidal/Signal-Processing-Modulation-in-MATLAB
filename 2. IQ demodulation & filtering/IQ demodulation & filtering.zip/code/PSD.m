function [Sx,faxis]=PSD(x,fs,flag)

% Computes PSD of x
% Inputs:
%    x: input vector
%    fs: sampling frequency (kHz)
%    flag: 0: no plot; 1: with plot
% Outputs:
%    Sx: PSD (Barlett estimator)
%    faxis: analog frequency axis (Hz) 

len=length(x); % vector length
N=1024; % block length
Nfft = 4*N; %  FFT length (zero padding)
K=floor(len/N); % number of averaged FFTs (for Barlett)
Sx=zeros(1,Nfft);
for k=0:K-1
    xblock=x(1+k*N:(k+1)*N);
    Sx=Sx+fftshift(abs(fft(xblock,Nfft)).^2); % FFT  (F=-1/2:1/Nfft:1/2-1/Nfft)
end
Sx=Sx/K;
faxis=fs*([0:Nfft-1]/Nfft-1/2)/1000; 
if flag
    plot(faxis,Sx/N^2); 
    xlim([-8 8]); xticks([-20:1:20]); xlabel('Frequency (kHz)'), 
    ylabel('Normalized PSD');
    grid on
end

end
