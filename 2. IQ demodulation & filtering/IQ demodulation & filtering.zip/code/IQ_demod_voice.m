clear all
close all

% ******************* Messages generation  *********************************

    % DAC parameters
    fs=44100;   % sampling frequency
    Ts=1/fs;   % sampling period
    
    load voices.mat % loads voice signals x1 and x2
    % sound(x1,fs)
    % sound(x2,fs)

    N=length(x1);   % signal length in samples
    n=[0:N-1];   % discrete time 

% ****************** Messages representation  *******************************

    % plots (time domain)
    fig1=figure(1);
    fig1.Units='normalized'; fig1.Position=[0.15 0.55 0.35 0.3];
    time=[0:N-1]*Ts*1000; % time axis in ms
    
    % x1
    subplot(211)
    hold on,grid on, ylim([-1 1]), xlim([0 N*Ts*1000]), xlabel('time (ms)'), ylabel('Amplitude')
    plot(time,x1,'b','LineWidth', 1.5)   % demodulated message
    title('x1 message')
    
    % x2
    subplot(212)
    hold on, grid on, ylim([-1 1]), xlim([0 N*Ts*1000]), xlabel('time (ms)'), ylabel('Amplitude')
    plot(time,x2,'b','LineWidth', 1.5)   % demodulated message
    title('x2 message')

   % plots (freq domain)
    fig2=figure(2);
    fig2.Units='normalized'; fig2.Position=[0.55 0.55 0.35 0.3];

    % x1
    subplot(211)
    PSD(x1,fs,1);
    title('x1 message')
    
    % x2
    subplot(212)
    PSD(x2,fs,1); 
    title('x2 message')
    
% ****************** I/Q Modulation  ***************************************

    % Carrier
    A0 = 1;   % carrier sinuoid amplitude
    f0 = 8000;   % carrier sinusoid analog frequency (cycles/second=Hz)

    % I/Q modulation  
    bs = A0*(x1+1i*x2);  % discrete (complex) baseband signal
    s = real(bs.*exp(1i*2*pi*f0*Ts*n));   % discrete I/Q signal
    % sound(s,fs);
    
% ****************** I/Q Demodulation  *************************************

    phiR = pi/16;   % receiver oscillator initial phase
    v1 = s.*2.*cos(2*pi*f0*Ts*n+phiR);
    v2 = s.*-2.*sin(2*pi*f0*Ts*n+phiR);
    
    load hb2    % loads filter designed with "filterDesigner"
                   % FIR Generalized Equiripple, Min Order, Apass=0.5; Astop=50dB
    iout = conv(v1,hb2);   
    qout = conv(v2,hb2);

% ****************** PLOTS (demodulated messages)  *************************

    % plots (time domain)
    fig3=figure(3);
    fig3.Units='normalized'; fig3.Position=[0.15 0.1 0.35 0.3];

    % I component
    subplot(211)
    hold on,grid on, ylim([-1 1]), xlim([0 N*Ts*1000]), xlabel('time (ms)'), ylabel('Amplitude')
    plot(time,iout(1:N),'b','LineWidth', 1.5)   % demodulated message
    title('I component (iout)')
    
    % Q component
    subplot(212)
    hold on, grid on, ylim([-1 1]), xlim([0 N*Ts*1000]), xlabel('time (ms)'), ylabel('Amplitude')
    plot(time,qout(1:N),'b','LineWidth', 1.5)   % demodulated message
    title('Q component (qout)')

    % plots (freq domain)
    fig4=figure(4);
    fig4.Units='normalized'; fig4.Position=[0.55 0.1 0.35 0.3];
    
    % I component
    subplot(211)
    PSD(iout(1:N),fs,1);
    title('I component (iout)')
    
    % Q component
    subplot(212)
    PSD(qout(1:N),fs,1); 
    title('Q component (qout)')



% -------------------------- Auxiliary functions ---------------------------------------------------

function [Sx,faxis]=PSD(x,fs,flag)

% Computes PSD of x
% Inputs:
%    x: input vector
%    fs: sampling frequency (kHz)
%    flag: 0: no plot; 1: with plot
% Outputs:
%    Sx: PSD (Barlett estimator)
%    faxis: analog frequency axis (Hz) 

len=length(x); % vector length
N=1024; % block length
Nfft = 4*N; %  FFT length (zero padding)
K=floor(len/N); % number of averaged FFTs (for Barlett)
Sx=zeros(1,Nfft);
for k=0:K-1
    xblock=x(1+k*N:(k+1)*N);
    Sx=Sx+fftshift(abs(fft(xblock,Nfft)).^2); % FFT  (F=-1/2:1/Nfft:1/2-1/Nfft)
end
Sx=Sx/K;
faxis=fs*([0:Nfft-1]/Nfft-1/2)/1000; 
if flag
    plot(faxis,Sx/N^2); 
    xlim([-8 8]); xticks([-20:1:20]); xlabel('Frequency (kHz)'), 
    ylabel('Normalized PSD');
    grid on
end

end
