clear all
close all

% ************** Received IQ signals generation  *********************************

    % DAC parameters
    fs=44100;   % sampling frequency
    Ts=1/fs;   % sampling period

    N=100000;   % signal length (in samples)
    n=[0:N-1];   % discrete time
    
    % Carrier
    A0 = 1;   % carrier sinuoid amplitude
    f0 = 4000;   % carrier sinusoid analog frequency (cycles/second=Hz)
    
    % In-Phase component    
    A1 = 1;   % modulating sinuoid amplitude
    f1 = 100;   % modulating sinusoid analog frequency (cycles/second=Hz)
    phi1 = 0;   % initial phase of the modulating sinusoid
    x1 = A1*cos(2*pi*f1*Ts*n); % first message

    % Quadrature component
    A2 = 0.5;   % modulating sinuoid amplitude
    f2 = 1000;   % modulating sinusoid analog frequency (cycles/second=Hz)
    phi2 = 0;   % initial phase of the modulating sinusoid
    x2 = A2*cos(2*pi*f2*Ts*n); % second message
 
    % I/Q modulation  
    bs = A0*(x1+1i*x2);  % discrete (complex) baseband signal
    s = real(bs.*exp(1i*2*pi*f0*Ts*n));   % discrete I/Q signal


% *********************** I/Q Demodulation  **********************************

    phiR = pi/4;   % receiver oscillator initial phase
    v1 = s.*2.*cos(2*pi*f0*Ts*n+phiR);
    v2 = s.*-2.*sin(2*pi*f0*Ts*n+phiR);
    
    load hb   % loads filter designed with "filterDesigner"
                  % FIR Generalized Equiripple, Min Order, Apass=0.5; Astop=50dB
    iout = conv(v1,hb);   
    qout = conv(v2,hb);


% ********************** PLOTS (demodulated messages)  ************************

  % plots (time domain)
    fig1=figure(1);
    fig1.Units='normalized'; fig1.Position=[0.1 0.3 0.4 0.5];
    
    Np=2; % number of represented periods of the slowest sinusoid
    Nplot=Np*ceil(1/(min(f1,f2)*Ts));
    time=[0:Nplot-1]*Ts*1000; % time axis in ms (3 periods of x1)
    
    % iout
    subplot(211)
    hold on,grid on, ylim([-1.5 1.5]), xlim([0 Nplot*Ts*1000]), xlabel('time (ms)'), ylabel('Amplitude'),
    plot(time,x1(1:Nplot),'r')   % transmitted message
    plot(time,iout(1:Nplot),'b','LineWidth', 1.5)   % demodulated message
    legend('x1', 'iout', 'Location', 'southeast');
    legend
    title('I component')
    
    % qout
    subplot(212)
    hold on, grid on, ylim([-1.5 1.5]), xlim([0 Nplot*Ts*1000]), , xlabel('time (ms)'), ylabel('Amplitude')
    plot(time,x2(1:Nplot),'r')   % transmitted message
    plot(time,qout(1:Nplot),'b','LineWidth', 1.5)   % demodulated message
    legend('x2', 'qout', 'Location', 'southeast');
    title('Q component')

    % plots (freq domain)
    fig2=figure(2);
    fig2.Units='normalized'; fig2.Position=[0.55 0.3 0.4 0.5];
    
    % iout
    subplot(211)
    PSD(iout,fs,1); title('I component (iout)')
    
    % qout
    subplot(212)
    PSD(qout,fs,1); title('Q component (qout)')
   



% ------------------------ Auxiliary functions --------------------------------------------------------

function [Sx,faxis]=PSD(x,fs,flag)

% Computes PSD of x
% Inputs:
%    x: input vector
%    fs: sampling frequency (kHz)
%    flag: 0: no plot; 1: with plot
% Outputs:
%    Sx: PSD (Barlett estimator)
%    faxis: analog frequency axis (Hz) 

len=length(x); % vector length
N=1024; % block length
Nfft = 4*N; %  FFT length (zero padding)
K=floor(len/N); % number of averaged FFTs (for Barlett)
Sx=zeros(1,Nfft);
for k=0:K-1
    xblock=x(1+k*N:(k+1)*N);
    Sx=Sx+fftshift(abs(fft(xblock,Nfft)).^2); % FFT  (F=-1/2:1/Nfft:1/2-1/Nfft)
end
Sx=Sx/K;
faxis=fs*([0:Nfft-1]/Nfft-1/2)/1000; 
if flag
    plot(faxis,Sx/N^2);
    xlim([-8 8]); xticks([-20:1:20]); xlabel('Frequency (kHz)'), 
    ylabel('Normalized PSD');
    grid on
end

end