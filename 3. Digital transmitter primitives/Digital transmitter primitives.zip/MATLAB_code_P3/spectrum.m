function [Xabs,faxis]=spectrum(x,fs,flag)
    
    % Computes Fourier Transform of vector x (magnitude)
    % Inputs:
    %    x: input vector
    %    fs: sampling frequency (kHz)
    %    flag: 0: no plot; 1: with plot
    % Outputs:
    %    Xabs: Fourier Transform of x (modulus)
    %    faxis: analog frequency axis (Hz) from -fs/2 to fs/2
    
    len=length(x); % vector length
    Nfft = 4*2^nextpow2(len); % FFT length (power of 2)
    Xabs=fftshift(abs(fft(x,Nfft))); % FFT modulus (F=-1/2:1/N:1/2-1/N)
    faxis=fs*([0:Nfft-1]/Nfft-1/2)/1000; 
    if flag
        plot(faxis,Xabs.^2); 
        xlim([-20 20]); xticks([-20:0.5:20]); xlabel('Frequency (kHz)'), 
        %ylim([0 5000]);
        ylabel('PSD estimation');
        grid on
        drawnow
    end

end