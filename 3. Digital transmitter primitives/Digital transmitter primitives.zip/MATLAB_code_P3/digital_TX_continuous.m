clear all
close all

fs=44100;       % sampling frequency
Ts=1/fs;        % sampling period
Nss=50;        % oversampling (samples/symbol)
Tsym=Ts*Nss;    % symbol period
modulation_type = 'qpsk';        % bpsk, qpsk, 2-uni, 4-uni, 4-pol, 16-qam
p = 0.5;        % probability of bit=1
A = 1;          % separation between adjacent symbols


A0 = 1/20;   % carrier sinuoid amplitude
          % NOTE !!!: this amplitude has to be changed if the amplitude of
          % the signal sent to the DAC is higher than 1

f0 = fs/4;   % carrier sinusoid analog frequency (cycles/second=Hz)
phi0 = 0; % initial phase of the carrier


Pulse.type='srrc___';                      % rectNRZ: rectangular of duration Tsym; rectRZ_: rectangular of duration Tsym/2; srrc___: square-root raised cosine

if Pulse.type=='rectNRZ'
    g_pulse=ones(1,Nss)/sqrt(Tsym);     % NRZ rectangular pulse of unit energy
elseif Pulse.type=='rectRZ_'
    g_pulse=ones(1,Nss/2)/sqrt(Tsym/2);     % RZ rectangular pulse of unit energy (50% duty cycle)
elseif Pulse.type=='srrc___'
    Pulse.D=20;                          % pulse half-length, in symbol periods
    Pulse.alpha=0;                    % pulse roll-off (excess bandwidth)
    g_pulse=srrc(Pulse.D, Pulse.alpha, Nss, Tsym);    % SRRC pulse of unit energy
end
Lpulse=length(g_pulse);                 % pulse length in samples



num_symbols_block = 100;                % block length (in symbols)
N = num_symbols_block*Nss;              % block length (in samples)
n=[0:N-1];                              % discrete time within a block


deviceWriter = audioDeviceWriter('SampleRate',fs);   % creates Matlab object to send audio to the sound card

signal_block = zeros(1,max(N,N+Lpulse-Nss));
num_bits = num_symbols_block*num_bits_symbol(modulation_type);      % number of bits per block

while 1,   % infinite loop (stop pressing Ctrl+C)

tic

    % Generation of random bits and symbols

    bits = random_bits(num_bits,p);                        % sequence of random independent bits with probability(bit=1) = p
    symbols = mapping(bits,modulation_type,A);      % mapping from bits to symbols

    
    % ----------------------- complex baseband signal --------------------------------------------------------------
    
    for k=1:num_symbols_block,
        signal_block((k-1)*Nss+(1:Lpulse)) = signal_block((k-1)*Nss+(1:Lpulse))+symbols(k)*g_pulse;
    end
    bs = A0*signal_block(1:N);
    if Lpulse <= Nss,
        signal_block = zeros(1,N);
    elseif Lpulse > Nss
        signal_block(1:(Lpulse-Nss)) = signal_block((N+1):end);
        signal_block((Lpulse-Nss+1):end) = 0;
    end

    % ----------------------- bandpass signal ----------------------------------------------------------------------
       
    signal_out = real(bs.*exp(1i*(2*pi*f0*n*Ts+phi0)));   % discrete I/Q signal
    
    % ------------------------ DAC converter ----------------------------------------------------------------

    play(deviceWriter,signal_out');   % send block to the sound card 
    phi0 = mod(phi0 + 2*pi*f0*N*Ts,2*pi);   % initial carrier phase for next block

    % ------------------------ spectrum representation in MATLAB ------------------------------------------------------------
    
    [Xabs,faxis]=spectrum(signal_out,fs,1);   % computes and plots spectrum


    % ------------- display in screen the maximum amplitude of the signal sent to the ADC in this iteration ----------------

    mensaje = ['The maximum amplitude of the signal sent to the DAC in this iteration is ',num2str(max(abs(signal_out)))];
    disp(mensaje)

toc

end 

release(deviceWriter);