function bits=random_bits(Nb,p)
    bits = rand(1, Nb) < p;
end