clear all
close all

% V2 (21/02/2025): no access to ADC buffer for flow control

fs=44100;   % sampling frequency
Ts=1/fs;   % sampling period
N=4000;   % block length (in samples)
n=[0:N-1];   % discrete time within a block

deviceWriter = audioDeviceWriter('SampleRate',fs);   % creates Matlab object to send audio to the sound card

A=1;   % sinuoid amplitude (Warning: signal amplitude shall not exceed 1)
f0=4000;  % sinusoid analog frequency (cycles/second=Hz)
phi=0; % initial phase for the first block

if A>1
    error('A shoud not be higher than 1!')
end

while 1,   % infinite loop (stop pressing Ctrl+C)

    % ----------------------- Sinusoid generation ----------------------------------------------------
    signal_out =A*cos(2*pi*f0*n*Ts+phi);   % discrete sinusoid (amplitude A, frequency f0)
    % ---------------------------------------------------------------------------------------------------
    play(deviceWriter,signal_out');   % send block to the sound card 
    phi=mod(phi+2*pi*f0*N*Ts,2*pi);   % initial phase for next block
    
    [Xabs,faxis]=Spectrum(signal_out,fs,1);  % computes and plots spectrum 

end 

release(deviceWriter)

function [Xabs,faxis]=Spectrum(x,fs,flag)
    
    % Computes Fourier Transform of vector x (magnitude)
    % Inputs:
    %    x: input vector
    %    fs: sampling frequency (kHz)
    %    flag: 0: no plot; 1: with plot
    % Outputs:
    %    Xabs: Fourier Transform of x (modulus)
    %    faxis: analog frequency axis (Hz) from -fs/2 to fs/2
    
    len=length(x); % vector length
    Nfft = 4*2^nextpow2(len); % FFT length (power of 2) with zero-padding
    Xabs=fftshift(abs(fft(x,Nfft))); % FFT modulus (F=-1/2:1/N:1/2-1/N)
    faxis=fs*([0:Nfft-1]/Nfft-1/2)/1000; 
    if flag
        plot(faxis,Xabs/len); % Warning: scales sincs to have the same amplitude as the area of deltas without windowing
        xlim([-20 20]); xticks([-20:2:20]);  xlabel('Frequency (kHz)'), 
        ylim([0 0.6]); ylabel('Fourier Transform Magnitude');
        grid on
        drawnow
    end

end