clear all
close all

% V2 (21/02/2025): no access to ADC buffer for flow control

fs=44100;   % sampling frequency
Ts=1/fs;   % sampling period
N=4000;   % block length (in samples)

deviceWriter = audioDeviceWriter('SampleRate',fs);   % creates Matlab object to send audio to the sound card

A=1;   % square wave amplitude (Warning: signal amplitude shall not exceed 1)
f0=2000;   % intended square wave frequency (Hz)
T0=1/f0;   % intended square wave period (seconds)
P=2*round(T0/2*fs); % actual square wave period (samples)
Period=[ones(1,P/2) -ones(1,P/2)]; % single period of square wave
squareWave=kron(ones(1,ceil(N/P)+1),Period); % several periods of square wave
initial_time=1; % initial sample (within a period) for the first block

if A>1
    error('A shoud not be higher than 1!')
end

if f0>8000
    error('f0 should not be higher than 8000 Hz!')
end

while 1,   % infinite loop (stop pressing Ctrl+C)

    % ----------------------- Square wave generation --------------------------------------------------------------------------------
    signal_out =A*squareWave(initial_time:initial_time+N-1);   % discrete square wave (amplitude A, aprox. frequency f0)
    % ------------------------------------------------------------------------------------------------------------------------------------
    play(deviceWriter,signal_out');   % send block to the sound card 
    initial_time=mod(initial_time+N-1,P)+1;   % initial phase for next block
    [Xabs,faxis]=Spectrum(signal_out,fs,1);   % computes and plots spectrum  

end 

release(deviceWriter)

function [Xabs,faxis]=Spectrum(x,fs,flag)
    
    % Computes Fourier Transform of vector x (magnitude)
    % Inputs:
    %    x: input vector
    %    fs: sampling frequency (kHz)
    %    flag: 0: no plot; 1: with plot
    % Outputs:
    %    Xabs: Fourier Transform of x (modulus)
    %    faxis: analog frequency axis (Hz) from -fs/2 to fs/2
    
    len=length(x); % vector length
    Nfft = 4*2^nextpow2(len); % FFT length (power of 2)
    Xabs=fftshift(abs(fft(x,Nfft))); % FFT modulus (F=-1/2:1/N:1/2-1/N)
    faxis=fs*([0:Nfft-1]/Nfft-1/2)/1000; 
    if flag
        plot(faxis,Xabs/len); % Warning: scales sincs to have the same amplitude as the area of deltas without windowing
        xlim([-20 20]); xticks([-20:2:20]); xlabel('Frequency (kHz)'), 
        ylim([0 0.7]); ylabel('Normalized Fourier Transform Magnitude');
        grid on
        drawnow
    end

end