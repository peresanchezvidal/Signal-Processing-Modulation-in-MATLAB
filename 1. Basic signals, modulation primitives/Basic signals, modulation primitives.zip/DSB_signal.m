clear all
close all

% V2 (21/02/2025): no access to ADC buffer for flow control

fs=44100;   % sampling frequency
Ts=1/fs;   % sampling period
N=4000;   % block length (in samples)
n=[0:N-1];   % discrete time within a block

deviceWriter = audioDeviceWriter('SampleRate',fs);   % creates Matlab object to send audio to the sound card

A0 = 1;   % carrier sinuoid amplitude
f0 = 2000;   % carrier sinusoid analog frequency (cycles/second=Hz)
phi0 = 0; % initial phase of the carrier sinusoid

Ax = 0.5;   % modulating sinuoid amplitude
fx = f0/8;   % modulating sinusoid analog frequency (cycles/second=Hz)
phix = pi; % initial phase of the modulating sinusoid

if A0*Ax>1
    error('A0*Ax shoud not be higher than 1!')
end


while 1,   % infinite loop (stop pressing Ctrl+C)
    % ----------------------- DSB signal generation -----------------------------------------------------------
    signal_out = A0*Ax*cos(2*pi*fx*n*Ts+phix).*cos(2*pi*f0*n*Ts+phi0);   % discrete DSB signal
    % ---------------------------------------------------------------------------------------------------------
    play(deviceWriter,signal_out');   % send block to the sound card 
    phi0 = mod(phi0+2*pi*f0*N*Ts,2*pi);   % initial carrier phase for next block
    phix = mod(phix+2*pi*f0*N*Ts,2*pi);   % initial modulating phase for next block

    [Xabs,faxis]=Spectrum(signal_out,fs,1);   % computes and plots spectrum 

end 

release(deviceWriter)


function [Xabs,faxis]=Spectrum(x,fs,flag)
    
    % Computes Fourier Transform of vector x (magnitude)
    % Inputs:
    %    x: input vector
    %    fs: sampling frequency (kHz)
    %    flag: 0: no plot; 1: with plot
    % Outputs:
    %    Xabs: Fourier Transform of x (modulus)
    %    faxis: analog frequency axis (Hz) from -fs/2 to fs/2
    
    len=length(x); % vector length
    Nfft = 4*2^nextpow2(len); % FFT length (power of 2)
    Xabs=fftshift(abs(fft(x,Nfft))); % FFT modulus (F=-1/2:1/N:1/2-1/N)
    faxis=fs*([0:Nfft-1]/Nfft-1/2)/1000; 
    if flag
        plot(faxis,Xabs/len); % Warning: scales sincs to have the same amplitude as the area of deltas without windowing
        xlim([-20 20]); xticks([-20:2:20]); xlabel('Frequency (kHz)'), 
        ylim([0 0.3]); ylabel('Normalized Fourier Transform Magnitude');
        grid on
        drawnow
    end

end