clear all
close all

% V2 (21/02/2025): no access to ADC buffer for flow control

fs=44100;   % sampling frequency
Ts=1/fs;   % sampling period
N=4000;   % block length (in samples)
n=[0:N-1];   % discrete time within a block

deviceWriter = audioDeviceWriter('SampleRate',fs);   % creates Matlab object to send audio to the sound card

A0 = 0.5;   % carrier sinuoid amplitude
f0 = 2000;   % carrier sinusoid analog frequency (cycles/second=Hz)
phi0 = 0; % initial phase of the carrier sinusoid

% In-Phase
A1 = 0.5;   % modulating sinuoid amplitude
f1 = f0/8;   % modulating sinusoid analog frequency (cycles/second=Hz)
phi1 = pi;   % initial phase of the modulating sinusoid

% Quadrature
A2 = 0.7;   % modulating sinuoid amplitude
f2 = f0/2;   % modulating sinusoid analog frequency (cycles/second=Hz)
phi2 = pi/2;   % initial phase of the modulating sinusoid


while 1,   % infinite loop (stop pressing Ctrl+C)
    % ----------------------- I/Q signal -------- -----------------------------------------------------------
    bs = A0*A1*cos(2*pi*f1*n*Ts+phi1)+1i*A0*A2*cos(2*pi*f2*n*Ts+phi2);    % discrete baseband signal
    signal_out = real(bs.*exp(1i*(2*pi*f0*n*Ts+phi0))) ;   % discrete I/Q signal
    % ---------------------------------------------------------------------------------------------------------
    play(deviceWriter,signal_out');   % send block to the sound card 
    phi0=mod(phi0+2*pi*f0*N*Ts,2*pi);   % initial carrier phase for next block
    phi1=mod(phi1+2*pi*f1*N*Ts,2*pi);   % initial modulating phase for next block (in-phase)
    phi2=mod(phi2+2*pi*f2*N*Ts,2*pi);   % initial modulating phase for next block (quadrature)
    
    [Xabs,faxis]=Spectrum(signal_out,fs,1);   % computes and plots spectrum 
end 

release(deviceWriter);


function [Xabs,faxis]=Spectrum(x,fs,flag)
    
    % Computes Fourier Transform of vector x (magnitude)
    % Inputs:
    %    x: input vector
    %    fs: sampling frequency (kHz)
    %    flag: 0: no plot; 1: with plot
    % Outputs:
    %    Xabs: Fourier Transform of x (modulus)
    %    faxis: analog frequency axis (Hz) from -fs/2 to fs/2
    
    len=length(x); % vector length
    Nfft = 4*2^nextpow2(len); % FFT length (power of 2)
    Xabs=fftshift(abs(fft(x,Nfft))); % FFT modulus (F=-1/2:1/N:1/2-1/N)
    faxis=fs*([0:Nfft-1]/Nfft-1/2)/1000; 
    if flag
        plot(faxis,Xabs/len); % Warning: scales sincs to have the same amplitude as the area of deltas without windowing 
        xlim([-20 20]); xticks([-20:2:20]); xlabel('Frequency (kHz)'), 
        ylim([0 0.2]); ylabel('Normalized Fourier Transform Magnitude');
        grid on
        drawnow
    end

end